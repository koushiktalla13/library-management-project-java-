/** Base class for all custom exceptions in the system (shows exception inheritance). */
public class LibraryException extends Exception {
    private static final long serialVersionUID = 1L;

    public LibraryException(String message) {
        super(message);
    }
}
