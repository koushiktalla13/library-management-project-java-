import java.io.*;

/** Saves and loads the whole Library object using Java serialization (file I/O). */
public class FileHandler {

    public static void save(Library library, String fileName) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName))) {
            out.writeObject(library);
            System.out.println("Data saved to " + fileName);
        } catch (IOException e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }

    public static Library load(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            return null;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (Library) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not load saved data: " + e.getMessage());
            return null;
        }
    }
}
