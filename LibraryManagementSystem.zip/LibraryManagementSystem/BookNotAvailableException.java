/** Thrown when someone tries to issue a book that is already issued. */
public class BookNotAvailableException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public BookNotAvailableException(String message) {
        super(message);
    }
}
