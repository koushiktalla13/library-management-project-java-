/** Thrown when a member tries to borrow more books than allowed. */
public class LimitExceededException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public LimitExceededException(String message) {
        super(message);
    }
}
