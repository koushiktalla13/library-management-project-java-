import java.io.Serializable;
import java.time.LocalDate;

/** Records one issue/return event of a book. */
public class Transaction implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int bookId;
    private final int memberId;
    private final LocalDate issueDate;
    private final LocalDate dueDate;
    private LocalDate returnDate; // null while the book is still issued
    private double fine;

    public Transaction(int bookId, int memberId, LocalDate issueDate, int loanDays) {
        this.bookId = bookId;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.dueDate = issueDate.plusDays(loanDays);
    }

    public void close(LocalDate returnDate, double fine) {
        this.returnDate = returnDate;
        this.fine = fine;
    }

    public boolean isActive()        { return returnDate == null; }
    public int getBookId()           { return bookId; }
    public int getMemberId()         { return memberId; }
    public LocalDate getIssueDate()  { return issueDate; }
    public LocalDate getDueDate()    { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public double getFine()          { return fine; }

    @Override
    public String toString() {
        return String.format("Book %-5d Member %-6d Issued: %s  Due: %s  Returned: %s  Fine: Rs.%.2f",
                bookId, memberId, issueDate, dueDate,
                returnDate == null ? "-" : returnDate.toString(), fine);
    }
}
