import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/** Console menu for the Library Management System. */
public class Main {
    private static final String DATA_FILE = "library.dat";
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Library library = FileHandler.load(DATA_FILE);
        if (library == null) {
            library = new Library();
            loadSampleData(library);
            System.out.println("No saved data found. Starting with sample data.");
        } else {
            System.out.println("Saved data loaded.");
        }

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter choice: ");
            try {
                switch (choice) {
                    case 1:  addBook(library);            break;
                    case 2:  registerMember(library);     break;
                    case 3:  viewBooks(library);          break;
                    case 4:  searchBooks(library);        break;
                    case 5:  issueBook(library);          break;
                    case 6:  returnBook(library);         break;
                    case 7:  viewMemberBooks(library);    break;
                    case 8:  viewOverdue(library);        break;
                    case 9:  viewHistory(library);        break;
                    case 10: viewMembers(library);        break;
                    case 0:
                        FileHandler.save(library, DATA_FILE);
                        running = false;
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (LibraryException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    // ---------- Menu ----------
    private static void printMenu() {
        System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
        System.out.println(" 1. Add book");
        System.out.println(" 2. Register member");
        System.out.println(" 3. View all books");
        System.out.println(" 4. Search books");
        System.out.println(" 5. Issue book");
        System.out.println(" 6. Return book");
        System.out.println(" 7. View books borrowed by a member");
        System.out.println(" 8. View overdue books");
        System.out.println(" 9. View transaction history");
        System.out.println("10. View all members");
        System.out.println(" 0. Save & exit");
    }

    // ---------- Actions ----------
    private static void addBook(Library library) {
        String title = readLine("Title: ");
        String author = readLine("Author: ");
        Book b = library.addBook(title, author);
        System.out.println("Book added with ID " + b.getId());
    }

    private static void registerMember(Library library) {
        String name = readLine("Name: ");
        String type = readLine("Type (S = Student, F = Faculty): ");
        Member m = library.addMember(name, type.equalsIgnoreCase("F"));
        System.out.println(m.getType() + " registered with ID " + m.getId());
    }

    private static void viewBooks(Library library) {
        List<Book> books = library.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
            return;
        }
        System.out.printf("%-6s %-30s %-20s %s%n", "ID", "Title", "Author", "Status");
        for (Book b : books) {
            System.out.println(b);
        }
    }

    private static void searchBooks(Library library) {
        String keyword = readLine("Search by title or author: ");
        List<Book> results = library.searchBooks(keyword);
        if (results.isEmpty()) {
            System.out.println("No matching books found.");
        } else {
            for (Book b : results) {
                System.out.println(b);
            }
        }
    }

    private static void issueBook(Library library) throws LibraryException {
        int bookId = readInt("Book ID: ");
        int memberId = readInt("Member ID: ");
        LocalDate date = readDateOrToday("Issue date (yyyy-MM-dd) or press Enter for today: ");
        Transaction t = library.issueBook(bookId, memberId, date);
        System.out.println("Book issued. Due date: " + t.getDueDate());
    }

    private static void returnBook(Library library) throws LibraryException {
        int bookId = readInt("Book ID: ");
        LocalDate date = readDateOrToday("Return date (yyyy-MM-dd) or press Enter for today: ");
        Transaction t = library.returnBook(bookId, date);
        System.out.println("Book returned.");
        if (t.getFine() > 0) {
            System.out.printf("Late return! Fine to pay: Rs.%.2f%n", t.getFine());
        } else {
            System.out.println("Returned on time. No fine.");
        }
    }

    private static void viewMemberBooks(Library library) throws LibraryException {
        int memberId = readInt("Member ID: ");
        Member m = library.findMember(memberId);
        List<Integer> ids = m.getBorrowedBookIds();
        System.out.println(m.getName() + " (" + m.getType() + ") has borrowed " + ids.size() + " book(s):");
        for (int id : ids) {
            System.out.println("  " + library.findBook(id));
        }
    }

    private static void viewOverdue(Library library) {
        List<Transaction> overdue = library.getOverdueTransactions();
        if (overdue.isEmpty()) {
            System.out.println("No overdue books.");
        } else {
            for (Transaction t : overdue) {
                System.out.println(t);
            }
        }
    }

    private static void viewHistory(Library library) {
        List<Transaction> all = library.getTransactions();
        if (all.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (Transaction t : all) {
                System.out.println(t);
            }
        }
    }

    private static void viewMembers(Library library) {
        for (Member m : library.getAllMembers()) {
            System.out.println(m);
        }
    }

    // ---------- Input helpers (with validation) ----------
    private static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static LocalDate readDateOrToday(String prompt) {
        while (true) {
            String input = readLine(prompt);
            if (input.isEmpty()) {
                return LocalDate.now();
            }
            try {
                return LocalDate.parse(input);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date. Use the format yyyy-MM-dd.");
            }
        }
    }

    private static void loadSampleData(Library library) {
        library.addBook("Java: The Complete Reference", "Herbert Schildt");
        library.addBook("Effective Java", "Joshua Bloch");
        library.addBook("Head First Java", "Kathy Sierra");
        library.addBook("Clean Code", "Robert C. Martin");
        library.addBook("Introduction to Algorithms", "Thomas Cormen");
        library.addMember("Asha", false);
        library.addMember("Dr. Rao", true);
    }
}
