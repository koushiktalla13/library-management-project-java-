/** A faculty member: 5 books, 30 days, Rs. 1 fine per late day. */
public class Faculty extends Member {
    private static final long serialVersionUID = 1L;

    public Faculty(int id, String name) {
        super(id, name);
    }

    @Override public String getType()        { return "Faculty"; }
    @Override public int getMaxBooks()       { return 5; }
    @Override public int getLoanDays()       { return 30; }
    @Override public double getFinePerDay()  { return 1.0; }
}
