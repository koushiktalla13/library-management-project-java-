import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Core business logic of the system. The Main class only handles user interaction. */
public class Library implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Map<Integer, Book> books = new LinkedHashMap<>();
    private final Map<Integer, Member> members = new LinkedHashMap<>();
    private final List<Transaction> transactions = new ArrayList<>();
    private int nextBookId = 101;
    private int nextMemberId = 1001;

    // ---------- Adding data ----------
    public Book addBook(String title, String author) {
        Book book = new Book(nextBookId++, title, author);
        books.put(book.getId(), book);
        return book;
    }

    public Member addMember(String name, boolean isFaculty) {
        Member member;
        if (isFaculty) {
            member = new Faculty(nextMemberId++, name);
        } else {
            member = new Student(nextMemberId++, name);
        }
        members.put(member.getId(), member);
        return member;
    }

    // ---------- Lookups ----------
    public Book findBook(int id) throws ItemNotFoundException {
        Book book = books.get(id);
        if (book == null) {
            throw new ItemNotFoundException("No book found with ID " + id);
        }
        return book;
    }

    public Member findMember(int id) throws ItemNotFoundException {
        Member member = members.get(id);
        if (member == null) {
            throw new ItemNotFoundException("No member found with ID " + id);
        }
        return member;
    }

    public List<Book> searchBooks(String keyword) {
        List<Book> result = new ArrayList<>();
        String key = keyword.toLowerCase();
        for (Book b : books.values()) {
            if (b.getTitle().toLowerCase().contains(key)
                    || b.getAuthor().toLowerCase().contains(key)) {
                result.add(b);
            }
        }
        return result;
    }

    public List<Book> getAllBooks()     { return new ArrayList<>(books.values()); }
    public List<Member> getAllMembers() { return new ArrayList<>(members.values()); }
    public List<Transaction> getTransactions() { return new ArrayList<>(transactions); }

    // ---------- Issue ----------
    public Transaction issueBook(int bookId, int memberId, LocalDate issueDate)
            throws ItemNotFoundException, BookNotAvailableException, LimitExceededException {
        Book book = findBook(bookId);
        Member member = findMember(memberId);

        if (issueDate.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Issue date cannot be in the future.");
        }
        if (!book.isAvailable()) {
            throw new BookNotAvailableException("'" + book.getTitle() + "' is already issued.");
        }
        if (member.getBorrowedBookIds().size() >= member.getMaxBooks()) {
            throw new LimitExceededException(member.getName() + " (" + member.getType()
                    + ") has reached the limit of " + member.getMaxBooks() + " books.");
        }

        book.setAvailable(false);
        member.borrow(bookId);
        Transaction t = new Transaction(bookId, memberId, issueDate, member.getLoanDays());
        transactions.add(t);
        return t;
    }

    // ---------- Return (calculates fine) ----------
    public Transaction returnBook(int bookId, LocalDate returnDate) throws ItemNotFoundException {
        Book book = findBook(bookId);
        Transaction t = findActiveTransaction(bookId);
        if (t == null) {
            throw new ItemNotFoundException("Book " + bookId + " is not currently issued.");
        }
        if (returnDate.isBefore(t.getIssueDate())) {
            throw new IllegalArgumentException("Return date cannot be before the issue date ("
                    + t.getIssueDate() + ").");
        }

        if (returnDate.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Return date cannot be in the future.");
        }

        Member member = findMember(t.getMemberId());
        long daysLate = ChronoUnit.DAYS.between(t.getDueDate(), returnDate);
        double fine = daysLate > 0 ? daysLate * member.getFinePerDay() : 0;

        t.close(returnDate, fine);
        book.setAvailable(true);
        member.giveBack(bookId);
        return t;
    }

    private Transaction findActiveTransaction(int bookId) {
        for (Transaction t : transactions) {
            if (t.getBookId() == bookId && t.isActive()) {
                return t;
            }
        }
        return null;
    }

    // ---------- Reports ----------
    public List<Transaction> getOverdueTransactions() {
        List<Transaction> overdue = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (Transaction t : transactions) {
            if (t.isActive() && today.isAfter(t.getDueDate())) {
                overdue.add(t);
            }
        }
        return overdue;
    }
}
