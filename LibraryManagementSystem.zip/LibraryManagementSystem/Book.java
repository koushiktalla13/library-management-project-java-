import java.io.Serializable;

/** Represents a book in the library. Uses encapsulation: private fields + getters/setters. */
public class Book implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int id;
    private final String title;
    private final String author;
    private boolean available;

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.available = true;
    }

    public int getId()          { return id; }
    public String getTitle()    { return title; }
    public String getAuthor()   { return author; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("%-6d %-30s %-20s %s",
                id, title, author, available ? "Available" : "Issued");
    }
}
