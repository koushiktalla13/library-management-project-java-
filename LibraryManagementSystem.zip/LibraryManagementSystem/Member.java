import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Abstract parent class for all library members.
 * Subclasses (Student, Faculty) decide their own borrowing rules -> polymorphism.
 */
public abstract class Member implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int id;
    private final String name;
    private final List<Integer> borrowedBookIds = new ArrayList<>();

    public Member(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Abstract methods: every subclass MUST define its own rules
    public abstract String getType();
    public abstract int getMaxBooks();
    public abstract int getLoanDays();
    public abstract double getFinePerDay();

    public int getId()      { return id; }
    public String getName() { return name; }

    public List<Integer> getBorrowedBookIds() {
        return Collections.unmodifiableList(borrowedBookIds); // protect internal list
    }

    public void borrow(int bookId)   { borrowedBookIds.add(bookId); }
    public void giveBack(int bookId) { borrowedBookIds.remove(Integer.valueOf(bookId)); }

    @Override
    public String toString() {
        return String.format("%-6d %-20s %-8s Borrowed: %d/%d",
                id, name, getType(), borrowedBookIds.size(), getMaxBooks());
    }
}
