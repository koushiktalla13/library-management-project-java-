/** A student member: 3 books, 14 days, Rs. 2 fine per late day. */
public class Student extends Member {
    private static final long serialVersionUID = 1L;

    public Student(int id, String name) {
        super(id, name);
    }

    @Override public String getType()        { return "Student"; }
    @Override public int getMaxBooks()       { return 3; }
    @Override public int getLoanDays()       { return 14; }
    @Override public double getFinePerDay()  { return 2.0; }
}
