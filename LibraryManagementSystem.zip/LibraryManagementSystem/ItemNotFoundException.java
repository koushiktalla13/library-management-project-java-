/** Thrown when a book or member ID does not exist. */
public class ItemNotFoundException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public ItemNotFoundException(String message) {
        super(message);
    }
}
